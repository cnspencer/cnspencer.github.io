This is the 04AUG2017 update of the dragon.blend created by CNSpencer.
If you use this in anything public and/or commercial (monetized or not), please give credit for the original model to CNSpencer. Example on YouTube: mention name and/or link in video, description, and/or onscreen. (Seriously, is that too much to ask for?) You may modify the file however you like.

UPDATE LOG:
-Due to armature parenting errors, manually created vertex groups with correct weights
-Added mesh and armature to GroupTEST for fun
-Created bite and jump animations to test armature


Planned in the next update(s):
Touch up weight paints around upper neck
Toes! They need to be better!
Horns- new object/material?
(Figure out how to get eyes and teeth to match up better in edit mode of the dragon mesh)
(Improve teeth)
Maybe add simple animations for flying, walking, crouching, sitting
Eventually subdivide the whole dragon mesh for smoother appearence OR simplify/consolidate for game engine performance