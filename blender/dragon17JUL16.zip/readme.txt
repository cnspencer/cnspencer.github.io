This is the 17JUL2016 update of the dragon.blend created by CNSpencer.
If you use this in anything public and/or commercial (monetized or not), please give credit for the original model to CNSpencer. Example on YouTube: mention name and/or link in video, description, and/or onscreen. (Seriously, is that too much to ask for?) You may modify the file however you like.

UPDATE LOG:
Modified front legs and minimized blocky look (Still not perfect but definitely improved)
Fixed missing faces on outskirts of wings (Hopefully that will fix the problem I had 3D printing)
Slightly modified tail
Made chest slightly more narrow to fit in with feminine/feline-ish theme as achieved in hind legs
Moved wing posture
Changed hip posture
Added top-view camera (currently main)
Elongated tail, edited relevent armature and posture

Planned in the next update(s):
Toes! They need to be better!
Horns- new object/material?
Solve armature parents or something so it moves right through the haunches/lower neck
Figure out how to get eyes and teeth to match up better in edit mode of the dragon mesh
Improve teeth
Eventually subdivide the whole dragon mesh for smoother appearence