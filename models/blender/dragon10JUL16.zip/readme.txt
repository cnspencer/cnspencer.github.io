This is the 10JUL2016 update of the dragon.blend created by CNSpencer.
If you use this in anything public and/or commercial (monetized or not), please give credit for the original model to CNSpencer. (Seriously, is that too much to ask for?) You may modify it however you like.

UPDATE LOG:
Subdivided wings for smoother shape
Redid parent structures for eyes and teeth
Split teeth into two seperate objects for easier parenting and posture
Slightly modified overall posture