This is the 16OCT2019 update of the dragon.blend created by CNSpencer.
If you use this in anything public and/or commercial (monetized or not), please give credit for the original model to CNSpencer. Example on YouTube: mention name and/or link in video, description, and/or onscreen. You may modify the file however you like.

UPDATE LOG:
-Added "Defensive" animation


dragon.blend may or may not be updated in the future
Planned in the next update(s) in somewhat chronological order:
Improve "Small Bite" to be more aggresive
Touch up weight paints around upper neck
Toes! They need to be better!
Horns- new object/material?
(Figure out how to get eyes and teeth to match up better in edit mode of the dragon mesh)
(Improve teeth)
Maybe add simple animations for walking, crouching, sitting, and more specific animations (e.g. "Runningleft")
Eventually subdivide the whole dragon mesh for smoother appearence OR simplify/consolidate/multiresolution for game engine performance