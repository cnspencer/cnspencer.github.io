/**
 * The cardNums are as follows:
 *
 * 1 - Hearts
 * 2 - Clubs
 * 3 - Spades
 * 4 - Diamonds
 *
 */

public enum Suits {
    HEARTS, CLUBS, SPADES, DIAMONDS
}
