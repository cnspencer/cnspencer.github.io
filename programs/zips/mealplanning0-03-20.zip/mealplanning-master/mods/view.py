
import food


def main(ls):
	for foo in ls:
		print(str(foo) + "\n")
